"""Ties the FSA, lexicon and report together."""

from collections import defaultdict
from dataclasses import dataclass, field

from .fsa import TermAutomaton, Match
from .lexicon import LEXICON

NEUTRAL_MESSAGE = "The text has gender-neutral language."


@dataclass
class Result:
    text: str
    matches: list
    summary: dict = field(default_factory=dict)  # term -> count

    @property
    def is_neutral(self):
        return not self.matches


class Analyzer:
    def __init__(self, lexicon=None):
        self.lexicon = lexicon or LEXICON
        self.fsa = TermAutomaton(self.lexicon.keys())

    def analyze(self, text):
        matches = self.fsa.find_all(text)
        summary = defaultdict(int)
        for m in matches:
            summary[m.term] += 1
        return Result(text, matches, dict(summary))

    def suggestions(self, term):
        return self.lexicon[term]


def _line_col(text, pos):
    line = text.count("\n", 0, pos) + 1
    col = pos - (text.rfind("\n", 0, pos) + 1) + 1
    return line, col


def build_report(result, analyzer, source="(pasted text)"):
    if result.is_neutral:
        return NEUTRAL_MESSAGE
    lines = [
        "GENDER-NEUTRAL LANGUAGE REPORT",
        f"Source: {source}",
        "=" * 60,
        f"Gender-specific terms found: {len(result.matches)} "
        f"({len(result.summary)} distinct)",
        "",
        f"{'Term':<22}{'Count':>6}  Suggested alternative(s)",
        "-" * 60,
    ]
    for term, count in sorted(result.summary.items(), key=lambda kv: (-kv[1], kv[0])):
        lines.append(f"{term:<22}{count:>6}  {', '.join(analyzer.suggestions(term))}")
    lines += ["", "Occurrences", "-" * 60]
    for m in result.matches:
        ln, col = _line_col(result.text, m.start)
        a = max(0, m.start - 25)
        b = min(len(result.text), m.end + 25)
        ctx = result.text[a:b].replace("\n", " ")
        lines.append(f"Line {ln}, col {col}: \"{m.text}\" -> "
                     f"{' / '.join(analyzer.suggestions(m.term))}")
        lines.append(f"    ...{ctx}...")
    return "\n".join(lines)
