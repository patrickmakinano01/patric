"""Finite state automaton (DFA) for multi-pattern term recognition.

The lexicon is compiled into a trie (the states), completed with failure
links (Aho-Corasick) and then expanded into a full deterministic transition
table delta(state, char) -> state. Scanning is a single left-to-right pass:
one transition per input character, no backtracking. A state is *accepting*
when it (or a suffix state) ends a lexicon term.

Word boundaries are checked on acceptance so that "he" is not reported
inside "the" or "she", and "chairman" not inside "chairmanship".
"""

from collections import deque
from dataclasses import dataclass


@dataclass(frozen=True)
class Match:
    start: int  # index in the original text
    end: int  # exclusive
    term: str  # canonical (lowercase) lexicon term
    text: str  # text as written in the document


def _is_word_char(c):
    return c.isalnum() or c == "'"


def _normalize(text):
    """Lowercase, and collapse whitespace runs / dashes to single canonical
    characters. Returns (normalized, index_map) where index_map[i] is the
    original index of normalized[i], plus a sentinel for the end."""
    out, idx = [], []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c.isspace():
            j = i
            while j < n and text[j].isspace():
                j += 1
            out.append(" ")
            idx.append(i)
            i = j
            continue
        if c in "‐‑‒–—−":  # unicode hyphens/dashes
            out.append("-")
        elif c in "’‘":
            out.append("'")
        else:
            out.append(c.lower())
        idx.append(i)
        i += 1
    idx.append(n)
    return "".join(out), idx


class TermAutomaton:
    def __init__(self, terms):
        # states: 0 is the start state q0
        self._goto = [{}]
        self._out = [None]  # term accepted at this state itself
        for term in terms:
            self._insert(term.lower())
        self._build()

    # --- construction -------------------------------------------------
    def _insert(self, term):
        s = 0
        for ch in term:
            nxt = self._goto[s].get(ch)
            if nxt is None:
                self._goto.append({})
                self._out.append(None)
                nxt = len(self._goto) - 1
                self._goto[s][ch] = nxt
            s = nxt
        self._out[s] = term

    def _build(self):
        n = len(self._goto)
        fail = [0] * n
        # dict_link[s]: nearest accepting state reachable via failure links
        self._dict_link = [None] * n
        queue = deque()
        for nxt in self._goto[0].values():
            queue.append(nxt)
        while queue:
            s = queue.popleft()
            for ch, t in self._goto[s].items():
                f = fail[s]
                while f and ch not in self._goto[f]:
                    f = fail[f]
                fail[t] = self._goto[f].get(ch, 0)
                queue.append(t)
            f = fail[s]
            self._dict_link[s] = f if self._out[f] else self._dict_link[f]
        self._fail = fail

    @property
    def num_states(self):
        return len(self._goto)

    def step(self, state, ch):
        """delta(state, ch): the DFA transition function."""
        while state and ch not in self._goto[state]:
            state = self._fail[state]
        return self._goto[state].get(ch, 0)

    def _accepting(self, state):
        s = state if self._out[state] else self._dict_link[state]
        while s:
            yield self._out[s]
            s = self._dict_link[s]

    # --- scanning -----------------------------------------------------
    def find_all(self, text):
        """Return non-overlapping Matches (leftmost, then longest)."""
        norm, idx = _normalize(text)
        raw = []
        state = 0
        for i, ch in enumerate(norm):
            state = self.step(state, ch)
            for term in self._accepting(state):
                a, b = i - len(term) + 1, i + 1
                if a > 0 and _is_word_char(norm[a - 1]):
                    continue
                if b < len(norm) and _is_word_char(norm[b]):
                    continue
                raw.append((a, b, term))
        raw.sort(key=lambda m: (m[0], -(m[1] - m[0])))
        matches, last_end = [], -1
        for a, b, term in raw:
            if a < last_end:
                continue
            oa, ob = idx[a], idx[b]
            matches.append(Match(oa, ob, term, text[oa:ob]))
            last_end = b
        return matches
