# Gender-Neutral Language Recognizer

A software application that uses a **finite state automaton (FSA)** to recognize gender-specific
terms in text documents and suggest gender-neutral alternatives.

Two interchangeable front ends share the same design:

| Version | Location | Run |
|---|---|---|
| **Web app** (recommended UI) | `web/` | open `web/index.html` in a browser |
| **Python desktop app + CLI** | `main.py`, `gnl/` | `python main.py` |

## Quick start

### Web app
1. Open `web/index.html` (double-click it). If PDF/Word upload fails because of browser file
   restrictions, serve it instead:
   `python -m http.server 8000 --directory web` then visit <http://localhost:8000>.
2. Drop a `.txt`, `.docx` or `.pdf` file, or paste text.
3. Read the results; click a highlighted term to replace it with a suggestion.

(`.docx` and `.pdf` reading uses the `mammoth` and `pdf.js` libraries from a CDN, so it needs internet.)

### Python version
```
pip install pypdf          # only needed for .pdf files
python main.py             # GUI
python main.py samples\biased.txt   # command line report
python -m unittest discover -s tests   # run tests
```
Requires Python 3.8+ (Tkinter is bundled with the Windows installer).

## Project layout
```
README.md
docs/
  DESIGN.md        FSA formal definition, algorithm, architecture
  USER_GUIDE.md    How to use both versions
  TESTING.md       Test plan, cases, requirement traceability
gnl/               Python package (fsa.py, lexicon.py, readers.py, analyzer.py)
main.py            Tkinter GUI and command-line entry point
tests/test_gnl.py  Unit tests
samples/           biased.txt, neutral.txt
web/               index.html, style.css, app.js, fsa.js, lexicon.js
```

## Requirements coverage
| # | Requirement | Where |
|---|---|---|
| 1 | Upload .txt, .docx, .pdf | `gnl/readers.py`, `web/app.js` (`readFile`) |
| 2 | Scan using finite state automata | `gnl/fsa.py`, `web/fsa.js` |
| 3 | Predefined gender-specific terms with neutral alternatives | `gnl/lexicon.py`, `web/lexicon.js` |
| 4 | Report of occurrences and suggested replacements | `gnl/analyzer.py` (`build_report`), `web/app.js` (`buildReport`) |
| 5 | "The text has gender-neutral language." when nothing found | banner / report in both versions |

See [docs/DESIGN.md](docs/DESIGN.md) for how the automaton works.
