import os
import sys
import tempfile
import unittest
import zipfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from gnl import Analyzer, build_report, read_document, NEUTRAL_MESSAGE

A = Analyzer()


def terms(text):
    return [m.term for m in A.analyze(text).matches]


class FsaTests(unittest.TestCase):
    def test_basic_terms(self):
        self.assertEqual(terms("The chairman said he would go."), ["chairman", "he"])

    def test_word_boundaries(self):
        # "he" inside "the"/"there"/"she"; "her" inside "other"
        self.assertEqual(terms("The other one is there."), [])
        self.assertEqual(terms("She left."), ["she"])
        self.assertEqual(terms("chairmanship"), [])

    def test_case_insensitive_preserves_text(self):
        m = A.analyze("STEWARDESS arrived").matches[0]
        self.assertEqual((m.term, m.text), ("stewardess", "STEWARDESS"))

    def test_longest_phrase_wins(self):
        self.assertEqual(terms("Each one should bring his or her own."), ["his or her"])
        self.assertEqual(terms("Ladies and gentlemen, welcome"), ["ladies and gentlemen"])

    def test_whitespace_and_hyphen_variants(self):
        self.assertEqual(terms("his  or\nher bag"), ["his or her"])
        self.assertEqual(terms("a man‑made lake"), ["man-made"])

    def test_punctuation_adjacent(self):
        self.assertEqual(terms("(he), \"she\"; him."), ["he", "she", "him"])

    def test_positions(self):
        text = "Ask the chairman."
        m = A.analyze(text).matches[0]
        self.assertEqual(text[m.start:m.end], "chairman")

    def test_neutral_message(self):
        r = A.analyze("They will bring their own lunch.")
        self.assertTrue(r.is_neutral)
        self.assertEqual(build_report(r, A), NEUTRAL_MESSAGE)

    def test_report_contents(self):
        text = "He met the stewardess. He left."
        rep = build_report(A.analyze(text), A)
        self.assertIn("he", rep)
        self.assertIn("flight attendant", rep)
        self.assertIn("they", rep)
        self.assertIn("3 ", rep.split("found:")[1][:4])


class ReaderTests(unittest.TestCase):
    def test_txt_and_docx(self):
        with tempfile.TemporaryDirectory() as d:
            t = os.path.join(d, "a.txt")
            open(t, "w", encoding="utf-8").write("The chairman spoke.")
            self.assertEqual(terms(read_document(t)), ["chairman"])

            dx = os.path.join(d, "a.docx")
            body = ('<w:document xmlns:w="http://schemas.openxmlformats.org/'
                    'wordprocessingml/2006/main"><w:body><w:p><w:r><w:t>The </w:t></w:r>'
                    '<w:r><w:t>stewardess</w:t></w:r></w:p></w:body></w:document>')
            with zipfile.ZipFile(dx, "w") as z:
                z.writestr("word/document.xml", body)
            self.assertEqual(terms(read_document(dx)), ["stewardess"])

    def test_unsupported(self):
        with self.assertRaises(Exception):
            read_document("x.xyz")


if __name__ == "__main__":
    unittest.main()
