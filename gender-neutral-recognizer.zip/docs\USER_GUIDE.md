# User Guide

## Web app (`web/index.html`)
1. **Load text.** Drag a file onto the dashed box, click *browse*, or paste/type into the editor.
   Supported: `.txt`, `.docx`, `.pdf`.
2. **Check the banner.** Blue = waiting, amber = terms found (with count), green =
   "The text has gender-neutral language."
3. **Highlighted view.** After uploading, the document switches to *Highlighted*. Click any
   highlighted term to see alternatives, then click one to replace it. Use *Edit* to type freely;
   results refresh automatically.
4. **Summary tab.** Each found term with its count and suggestions. Click a term to jump to its
   occurrences (click again for the next one).
5. **Report tab.** Full text report. *Download report* saves a `.txt`; *Copy* copies it.
6. **FSA inspector tab.** Type any word or phrase to see the automaton's state path and whether it
   is accepted. Green states are accepting.
7. **Clear** resets everything.

Notes: runs entirely in the browser; nothing is uploaded. `.docx`/`.pdf` readers load from a CDN,
so internet is needed for those two formats. Dark mode follows your system setting.

## Python desktop app (`python main.py`)
- **Upload document** – choose a `.txt`, `.docx` or `.pdf`; it is scanned immediately.
- **Scan text** – rescan after pasting or editing text in the Document panel.
- **Save report** – export the report as `.txt`.
- **Clear** – reset.
- Summary tab: click a term to jump to it (click again for the next occurrence). Full report tab shows the text report.

### Command line
```
python main.py samples\biased.txt
```
prints the report to the terminal.

## Troubleshooting
| Problem | Fix |
|---|---|
| PDF/Word upload fails in browser | Check internet, or serve with `python -m http.server 8000 --directory web` |
| "No text could be extracted" | The PDF is a scan (images); run OCR first |
| `.doc` rejected | Open in Word, Save As `.docx` |
| `ModuleNotFoundError: pypdf` | `pip install pypdf` |
| A term isn't flagged | Add it to the lexicon (see DESIGN.md §4) |
