# Testing

Run: `python -m unittest discover -s tests -v` (11 tests, all passing).

## Automated tests (`tests/test_gnl.py`)
| Test | Verifies |
|---|---|
| test_basic_terms | "The chairman said he would go." → `chairman`, `he` |
| test_word_boundaries | no hits in "other", "there", "chairmanship"; `she` found in "She left." |
| test_case_insensitive_preserves_text | "STEWARDESS" matched, original casing kept |
| test_longest_phrase_wins | `his or her`, `ladies and gentlemen` win over their parts |
| test_whitespace_and_hyphen_variants | multiple spaces/newline inside a phrase; non-breaking hyphen in `man-made` |
| test_punctuation_adjacent | `(he), "she"; him.` all recognized |
| test_positions | match offsets index the correct text |
| test_neutral_message | neutral text yields "The text has gender-neutral language." |
| test_report_contents | report lists terms, counts and alternatives |
| test_txt_and_docx | .txt and .docx files are read and scanned |
| test_unsupported | unsupported extension raises an error |

## Manual checks performed
- CLI on `samples/biased.txt` → 10 terms found; on `samples/neutral.txt` → neutral message.
- Tkinter GUI launches, scans text, highlights matches.
- Web app (served locally): scanning, highlighting, summary, replacement popover (replacement
  keeps capitalization and rescans), FSA inspector (`chairman` → accepted), dark/light themes.
- Not manually tested: uploading a real `.pdf`/`.docx` through the browser file dialog.

## Requirement traceability
| Requirement | Evidence |
|---|---|
| 1. Upload .txt/.docx/.pdf | `test_txt_and_docx`; PDF via pypdf/pdf.js (manual) |
| 2. FSA scanning | `gnl/fsa.py`, `web/fsa.js`; tests above |
| 3. Predefined term list + alternatives | `gnl/lexicon.py` (~60 terms) |
| 4. Report with occurrences and replacements | `test_report_contents`, CLI output |
| 5. Neutral message | `test_neutral_message`, green banner |

## Suggested extra manual test
Create a `.docx` and `.pdf` containing "The chairman and the stewardess…", upload each in both
versions, and confirm the same two terms are reported.
