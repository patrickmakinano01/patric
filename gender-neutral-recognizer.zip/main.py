"""Gender-Neutral Language Recognizer.

GUI:  python main.py
CLI:  python main.py path\\to\\file.docx
"""

import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from gnl import Analyzer, build_report, read_document, NEUTRAL_MESSAGE

BG = "#f4f6fb"
CARD = "#ffffff"
INK = "#1f2937"
MUTED = "#6b7280"
ACCENT = "#4f46e5"
ACCENT_DK = "#4338ca"
HIT = "#fde68a"
HIT_SEL = "#fb923c"
OK_BG, OK_FG = "#dcfce7", "#166534"
WARN_BG, WARN_FG = "#fef3c7", "#92400e"
INFO_BG, INFO_FG = "#e0e7ff", "#3730a3"

FONT = ("Segoe UI", 10)
FONT_B = ("Segoe UI", 10, "bold")


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Gender-Neutral Language Recognizer")
        self.geometry("1100x700")
        self.minsize(820, 520)
        self.configure(bg=BG)
        self.analyzer = Analyzer()
        self.source = "(pasted text)"
        self.result = None
        self._style()
        self._build()

    # ---------- styling ----------
    def _style(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure(".", font=FONT, background=BG, foreground=INK)
        s.configure("Card.TFrame", background=CARD)
        s.configure("Card.TLabel", background=CARD, foreground=INK)
        s.configure("Muted.TLabel", background=CARD, foreground=MUTED, font=("Segoe UI", 9))
        s.configure("Title.TLabel", background=CARD, font=("Segoe UI", 11, "bold"))
        s.configure("Primary.TButton", background=ACCENT, foreground="white",
                    font=FONT_B, padding=(14, 7), borderwidth=0)
        s.map("Primary.TButton", background=[("active", ACCENT_DK)])
        s.configure("Ghost.TButton", background=CARD, foreground=INK,
                    padding=(12, 7), bordercolor="#d1d5db", lightcolor=CARD, darkcolor=CARD)
        s.map("Ghost.TButton", background=[("active", "#eef0f6")])
        s.configure("Treeview", background=CARD, fieldbackground=CARD, rowheight=28,
                    borderwidth=0, font=FONT)
        s.configure("Treeview.Heading", background="#eef0f6", foreground=MUTED,
                    font=("Segoe UI", 9, "bold"), relief="flat", padding=6)
        s.map("Treeview", background=[("selected", INFO_BG)], foreground=[("selected", INFO_FG)])
        s.configure("TNotebook", background=CARD, borderwidth=0)
        s.configure("TNotebook.Tab", padding=(14, 6), font=FONT, background="#eef0f6")
        s.map("TNotebook.Tab", background=[("selected", CARD)])

    def _card(self, parent, title, subtitle=""):
        outer = tk.Frame(parent, bg="#e5e7eb")
        inner = ttk.Frame(outer, style="Card.TFrame", padding=12)
        inner.pack(fill="both", expand=True, padx=1, pady=1)
        head = ttk.Frame(inner, style="Card.TFrame")
        head.pack(fill="x", pady=(0, 8))
        ttk.Label(head, text=title, style="Title.TLabel").pack(side="left")
        if subtitle:
            ttk.Label(head, text=subtitle, style="Muted.TLabel").pack(side="left", padx=8)
        return outer, inner

    # ---------- layout ----------
    def _build(self):
        header = tk.Frame(self, bg=ACCENT)
        header.pack(fill="x")
        tk.Label(header, text="Gender-Neutral Language Recognizer", bg=ACCENT, fg="white",
                 font=("Segoe UI", 16, "bold")).pack(anchor="w", padx=20, pady=(14, 0))
        tk.Label(header, text="Finite state automaton scanner for gender-specific terms",
                 bg=ACCENT, fg="#c7d2fe", font=("Segoe UI", 10)).pack(anchor="w", padx=20, pady=(0, 14))

        bar = ttk.Frame(self, padding=(16, 12, 16, 4))
        bar.pack(fill="x")
        ttk.Button(bar, text="Upload document", style="Primary.TButton",
                   command=self.upload).pack(side="left")
        ttk.Button(bar, text="Scan text", style="Ghost.TButton",
                   command=self.scan).pack(side="left", padx=8)
        ttk.Button(bar, text="Save report", style="Ghost.TButton",
                   command=self.save_report).pack(side="left")
        ttk.Button(bar, text="Clear", style="Ghost.TButton",
                   command=self.clear).pack(side="left", padx=8)
        self.file_lbl = ttk.Label(bar, text="Supports .txt, .docx, .pdf  -  or paste text below",
                                  foreground=MUTED)
        self.file_lbl.pack(side="right")

        self.banner = tk.Label(self, text="Upload a document or paste text, then press Scan.",
                               bg=INFO_BG, fg=INFO_FG, font=("Segoe UI", 11, "bold"),
                               anchor="w", padx=16, pady=10)
        self.banner.pack(fill="x", padx=16, pady=(8, 8))

        panes = ttk.PanedWindow(self, orient="horizontal")
        panes.pack(fill="both", expand=True, padx=16, pady=(0, 16))

        # left: document
        lcard, linner = self._card(panes, "Document", "matches are highlighted")
        wrap = ttk.Frame(linner, style="Card.TFrame")
        wrap.pack(fill="both", expand=True)
        sb = ttk.Scrollbar(wrap)
        sb.pack(side="right", fill="y")
        self.text = tk.Text(wrap, wrap="word", undo=True, bd=0, highlightthickness=0,
                            font=("Segoe UI", 11), padx=6, pady=6, spacing2=3,
                            yscrollcommand=sb.set, insertbackground=INK)
        self.text.pack(fill="both", expand=True)
        sb.config(command=self.text.yview)
        self.text.tag_configure("hit", background=HIT)
        self.text.tag_configure("sel_hit", background=HIT_SEL, foreground="white")
        self.text.tag_raise("sel_hit")
        panes.add(lcard, weight=3)

        # right: results
        rcard, rinner = self._card(panes, "Results")
        self.chips = ttk.Frame(rinner, style="Card.TFrame")
        self.chips.pack(fill="x", pady=(0, 8))
        self.chip_total = self._chip(self.chips, "Occurrences")
        self.chip_distinct = self._chip(self.chips, "Distinct terms")

        nb = ttk.Notebook(rinner)
        nb.pack(fill="both", expand=True)
        t1 = ttk.Frame(nb, style="Card.TFrame")
        t2 = ttk.Frame(nb, style="Card.TFrame")
        nb.add(t1, text="Summary")
        nb.add(t2, text="Full report")

        cols = ("term", "count", "alt")
        self.tree = ttk.Treeview(t1, columns=cols, show="headings", selectmode="browse")
        for c, w, txt in (("term", 160, "Found"), ("count", 55, "Count"), ("alt", 200, "Suggested alternative")):
            self.tree.heading(c, text=txt, anchor="w")
            self.tree.column(c, width=w, anchor="w", stretch=(c == "alt"))
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<<TreeviewSelect>>", self._on_pick)
        ttk.Label(t1, text="Click a row to jump to its occurrences in the document.",
                  style="Muted.TLabel").pack(anchor="w", pady=(6, 0))

        self.report = tk.Text(t2, wrap="word", state="disabled", bd=0, highlightthickness=0,
                              font=("Consolas", 10), padx=6, pady=6)
        self.report.pack(fill="both", expand=True)
        panes.add(rcard, weight=2)

        self.jump_i = {}

    def _chip(self, parent, label):
        f = tk.Frame(parent, bg=INFO_BG, padx=14, pady=6)
        f.pack(side="left", padx=(0, 8))
        v = tk.Label(f, text="0", bg=INFO_BG, fg=INFO_FG, font=("Segoe UI", 16, "bold"))
        v.pack(anchor="w")
        tk.Label(f, text=label, bg=INFO_BG, fg=INFO_FG, font=("Segoe UI", 9)).pack(anchor="w")
        return v

    # ---------- actions ----------
    def upload(self):
        path = filedialog.askopenfilename(
            title="Choose a document",
            filetypes=[("Supported", "*.txt *.docx *.pdf"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            content = read_document(path)
        except Exception as e:
            messagebox.showerror("Cannot read file", str(e))
            return
        self.source = os.path.basename(path)
        self.file_lbl.config(text=self.source)
        self.text.delete("1.0", "end")
        self.text.insert("1.0", content)
        if not content.strip():
            messagebox.showwarning("Empty", "No text could be extracted (scanned PDF?).")
            return
        self.scan()

    def scan(self):
        content = self.text.get("1.0", "end-1c")
        if not content.strip():
            messagebox.showinfo("Nothing to scan", "Upload a document or paste some text first.")
            return
        r = self.result = self.analyzer.analyze(content)
        self.text.tag_remove("hit", "1.0", "end")
        self.text.tag_remove("sel_hit", "1.0", "end")
        for m in r.matches:
            self.text.tag_add("hit", f"1.0+{m.start}c", f"1.0+{m.end}c")

        self.tree.delete(*self.tree.get_children())
        for term, n in sorted(r.summary.items(), key=lambda kv: (-kv[1], kv[0])):
            self.tree.insert("", "end", iid=term,
                             values=(term, n, ", ".join(self.analyzer.suggestions(term))))
        self.chip_total.config(text=str(len(r.matches)))
        self.chip_distinct.config(text=str(len(r.summary)))
        self.jump_i = {}

        if r.is_neutral:
            self.banner.config(text=NEUTRAL_MESSAGE, bg=OK_BG, fg=OK_FG)
        else:
            self.banner.config(
                text=f"Found {len(r.matches)} gender-specific term(s). See suggestions at right.",
                bg=WARN_BG, fg=WARN_FG)
        self._set_report(build_report(r, self.analyzer, self.source))

    def _on_pick(self, _e):
        sel = self.tree.selection()
        if not sel or not self.result:
            return
        term = sel[0]
        hits = [m for m in self.result.matches if m.term == term]
        i = self.jump_i.get(term, -1) + 1
        if i >= len(hits):
            i = 0
        self.jump_i[term] = i
        m = hits[i]
        self.text.tag_remove("sel_hit", "1.0", "end")
        a, b = f"1.0+{m.start}c", f"1.0+{m.end}c"
        self.text.tag_add("sel_hit", a, b)
        self.text.see(a)
        # allow re-clicking the same row to cycle to the next occurrence
        self.after(50, lambda: self.tree.selection_remove(term))

    def _set_report(self, s):
        self.report.config(state="normal")
        self.report.delete("1.0", "end")
        self.report.insert("1.0", s)
        self.report.config(state="disabled")

    def save_report(self):
        s = self.report.get("1.0", "end-1c")
        if not s:
            messagebox.showinfo("No report", "Scan a document first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text", "*.txt")])
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(s)

    def clear(self):
        self.text.delete("1.0", "end")
        self.tree.delete(*self.tree.get_children())
        self._set_report("")
        self.result = None
        self.chip_total.config(text="0")
        self.chip_distinct.config(text="0")
        self.file_lbl.config(text="Supports .txt, .docx, .pdf  -  or paste text below")
        self.banner.config(text="Upload a document or paste text, then press Scan.",
                           bg=INFO_BG, fg=INFO_FG)


def cli(path):
    a = Analyzer()
    print(build_report(a.analyze(read_document(path)), a, os.path.basename(path)))


if __name__ == "__main__":
    if len(sys.argv) > 1:
        cli(sys.argv[1])
    else:
        App().mainloop()
